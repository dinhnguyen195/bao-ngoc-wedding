Thay các ảnh placeholder bằng ảnh thật, giữ nguyên tên file:
cover.jpg          ảnh nền màn hình mở thiệp
couple-main.jpg    ảnh cưới lớn trong trang
 gallery-1.jpg ... gallery-4.jpg  ảnh album
qr-bride.png       QR mừng cưới cô dâu
qr-groom.png       QR mừng cưới chú rể
music.mp3          nhạc nền (tùy chọn)

Gói khởi tạo không chứa ảnh cưới/QR/nhạc mẫu để tránh dùng nhầm tài sản của người khác. Khi chưa có ảnh, trình duyệt sẽ hiển thị nền màu trung tính.
