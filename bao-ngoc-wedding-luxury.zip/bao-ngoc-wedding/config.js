/* CHỈNH THÔNG TIN THIỆP TẠI ĐÂY. Không cần sửa index.html */
window.WEDDING = {
  groom: "Anh",
  bride: "Bình",
  dateISO: "2026-12-20T09:00:00+07:00", // YYYY-MM-DDTHH:mm:ss+07:00
  dateDisplay: "20 · 12 · 2026",
  dateLong: "CHỦ NHẬT · 20 THÁNG 12 · 2026",
  invitation: "Tình yêu là hành trình mà chúng tôi muốn cùng nhau viết tiếp. Sự hiện diện của bạn sẽ làm ngày vui của chúng tôi trở nên trọn vẹn hơn.",
  story: "Từ những điều bình dị nhất, chúng tôi tìm thấy nhau, cùng sẻ chia những niềm vui và viết nên câu chuyện của riêng mình. Và hôm nay, chúng tôi mong muốn được đón bạn trong khoảnh khắc đáng nhớ này.",
  coverImage: "assets/couple-main.jpg",
  gallery: ["assets/gallery-1.jpg", "assets/gallery-2.jpg", "assets/gallery-3.jpg", "assets/gallery-4.jpg"],
  music: "assets/music.mp3", // thêm file nhạc MP3 của bạn vào thư mục assets
  ceremony: { time: "09:00 · Chủ Nhật", date: "20 tháng 12, 2026", place: "Tư gia nhà trai", address: "Địa chỉ lễ thành hôn", map: "https://maps.google.com/?q=Phu+Cu+Hung+Yen" },
  party: { time: "11:00 · Chủ Nhật", date: "20 tháng 12, 2026", place: "Trung tâm tiệc cưới", address: "Địa chỉ tiệc cưới", map: "https://maps.google.com/?q=Phu+Cu+Hung+Yen" },
  brideGift: { bank: "NGÂN HÀNG", account: "0000000000", name: "TÊN CHỦ TÀI KHOẢN", qr: "assets/qr-bride.png" },
  groomGift: { bank: "NGÂN HÀNG", account: "0000000000", name: "TÊN CHỦ TÀI KHOẢN", qr: "assets/qr-groom.png" },
  /* Dán URL Web App Google Apps Script sau khi triển khai để lưu RSVP online. Để trống = chế độ demo trên trình duyệt. */
  rsvpEndpoint: ""
};
