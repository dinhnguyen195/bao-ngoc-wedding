BAO NGOC WEDDING – WEBSITE THIEP CUOI LUXURY
============================================

1. XEM THỬ TRÊN MÁY TÍNH
- Giải nén thư mục.
- Mở index.html bằng trình duyệt để xem giao diện.
- Một số trình duyệt hạn chế gửi form khi mở file trực tiếp. Nên chạy bằng VS Code Live Server hoặc đưa lên hosting tĩnh.

2. THAY THÔNG TIN THIỆP
Mở config.js bằng Notepad / VS Code và sửa:
- groom, bride: tên chú rể, cô dâu.
- dateISO: ngày giờ bắt đầu đếm ngược theo định dạng ISO có múi giờ +07:00.
- dateDisplay, dateLong: ngày hiển thị.
- invitation, story: nội dung lời mời/câu chuyện.
- ceremony, party: thời gian, địa chỉ, link Google Maps.
- brideGift, groomGift: ngân hàng, số tài khoản, chủ tài khoản, ảnh QR.
- rsvpEndpoint: URL Google Apps Script Web App (xem mục 4).

3. THAY ẢNH / NHẠC / QR
Thay file trong thư mục assets bằng ảnh của khách hàng, giữ đúng tên:
cover.jpg, couple-main.jpg, gallery-1.jpg đến gallery-4.jpg, qr-bride.png, qr-groom.png.
Nhạc nền: thêm assets/music.mp3. Chỉ sử dụng nhạc mà bạn có quyền sử dụng.
Khuyến nghị ảnh web JPG/WebP, chiều ngang 1600–2200px, tối ưu dung lượng trước khi tải lên.

4. LƯU RSVP ONLINE MIỄN PHÍ BẰNG GOOGLE SHEETS
A. Tạo một Google Sheet mới, đặt tên RSVP Wedding.
B. Mở Extensions > Apps Script, xóa code mẫu và dán đoạn sau:

function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  const d = JSON.parse(e.postData.contents);
  if (sheet.getLastRow() === 0) sheet.appendRow(['Thời gian','Thiệp','Họ tên','Điện thoại','Tham dự','Số khách','Lời chúc']);
  sheet.appendRow([new Date(), d.wedding || '', d.name || '', d.phone || '', d.attendance || '', d.guests || '', d.message || '']);
  return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
}

C. Chọn Deploy > New deployment > Web app.
D. Execute as: Me. Who has access: Anyone. Nhấn Deploy và cấp quyền theo hướng dẫn.
E. Sao chép URL Web App dạng https://script.google.com/macros/s/.../exec.
F. Dán URL vào rsvpEndpoint trong config.js.
G. Cập nhật lại website. Gửi thử một RSVP và kiểm tra Google Sheet.
Lưu ý: đây là endpoint công khai để khách gửi xác nhận; không đặt dữ liệu bí mật trong mã nguồn. Có thể bổ sung chống spam nếu lượng truy cập lớn.

5. ĐƯA WEBSITE LÊN INTERNET MIỄN PHÍ BẰNG GITHUB PAGES
A. Tạo tài khoản tại https://github.com nếu chưa có.
B. Tạo repository mới, ví dụ: bao-ngoc-wedding.
C. Upload toàn bộ file và thư mục trong gói này lên repository (index.html phải nằm ở thư mục gốc).
D. Vào Settings > Pages.
E. Trong Build and deployment, chọn Deploy from a branch; Branch: main; Folder: /(root); Save.
F. Chờ GitHub Pages triển khai. Địa chỉ thường có dạng https://TEN-TAI-KHOAN.github.io/bao-ngoc-wedding/.
G. Mỗi thiệp có thể tạo repository riêng hoặc tổ chức nhiều thư mục thiệp trong cùng repository, ví dụ /thiep/anh-binh/.

6. LƯU Ý VẬN HÀNH
- GitHub Pages miễn phí cho repository public theo điều kiện gói GitHub hiện hành; mã nguồn website và ảnh trong repository có thể được công khai.
- Tên miền riêng không bắt buộc; nếu mua tên miền sẽ phát sinh chi phí.
- RSVP cần triển khai Apps Script và cấp quyền truy cập phù hợp; kiểm thử trước khi gửi thiệp thật.
- QR ngân hàng cần là QR đúng tài khoản người nhận. Hãy kiểm tra bằng ứng dụng ngân hàng trước khi công bố.
- Không đưa thông tin đăng nhập, mật khẩu hoặc dữ liệu riêng tư vào config.js.

CẤU TRÚC
index.html       Giao diện thiệp
styles.css       Thiết kế responsive
app.js           Tương tác, countdown, gallery, RSVP
config.js        Thông tin từng đám cưới
assets/          Ảnh, QR, nhạc nền
